<?php

namespace App\Http\Controllers\Api;


use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserCode;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    /**
     * Login via email/password or phone/OTP
     */
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'nullable|email|exists:users,email',
            'phone' => 'nullable|string|exists:users,phone',
            'password' => 'nullable|string|min:6',
            'otp' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation Error',
                'errors' => $validator->errors()
            ], 422);
        }

        // Email & Password login
        if ($request->filled('email') && $request->filled('password')) {
            $user = User::where('email', $request->email)->first();

            if (!$user || !Hash::check($request->password, $user->password)) {
                return response()->json([
                    'status' => false,
                    'message' => 'Invalid email or password'
                ], 401);
            }

            $token = $user->createToken('auth_token')->plainTextToken;

            return response()->json([
                'status' => true,
                'message' => 'Login successful',
                'user' => $user,
                'token' => $token
            ]);
        }

        // Phone & OTP login
        if ($request->filled('phone') && $request->filled('otp')) {
            $userCode = UserCode::where('phone', $request->phone)
                                ->where('purpose', 'login')
                                ->latest()
                                ->first();

            if (!$userCode) {
                return response()->json(['status' => false, 'message' => 'OTP not found'], 404);
            }

            if (now()->gt($userCode->expires_at)) {
                return response()->json(['status' => false, 'message' => 'OTP expired'], 400);
            }

            if ($userCode->attempts >= 5) {
                return response()->json(['status' => false, 'message' => 'Too many attempts'], 429);
            }

            if (!Hash::check($request->otp, $userCode->code_hash)) {
                $userCode->increment('attempts');
                return response()->json(['status' => false, 'message' => 'Invalid OTP'], 400);
            }

            // OTP is valid; delete after successful login
            $userCode->delete();

            $user = User::where('phone', $request->phone)->first();

            if (!$user) {
                return response()->json(['status' => false, 'message' => 'User not found'], 404);
            }

            $token = $user->createToken('auth_token')->plainTextToken;

            return response()->json([
                'status' => true,
                'message' => 'Login successful',
                'user' => $user,
                'token' => $token
            ]);
        }

        return response()->json([
            'status' => false,
            'message' => 'Provide either email/password or phone/OTP'
        ], 400);
    }

    /**
     * Logout current token
     */
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'status' => true,
            'message' => 'Logged out successfully'
        ]);
    }

    /**
     * Get authenticated user profile
     */
    public function profile(Request $request)
    {
        return response()->json([
            'status' => true,
            'user' => $request->user()
        ]);
    }
}
