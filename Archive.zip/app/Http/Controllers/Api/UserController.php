<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Validator;
use App\Models\UserCode;
use Carbon\Carbon;
use App\Models\Employee;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;



class UserController extends Controller
{
    
    public function registerAndVerify(Request $request)
    {
        // Validate input
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'phone' => 'nullable|string|unique:users,phone|max:20',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string|min:6',
            'role' => ['required', Rule::in(['labor','customer','guard','super_admin'])],
            'is_active' => 'required|boolean',
            'otp' => 'required|string',

            // Employee-specific fields
            'experience_years' => 'required|string|max:50',
            'services' => 'required|array',
            'work_radius_km' => 'required|integer',
            'hourly_rate' => 'required|numeric',
            'availability' => 'required|string',
            'about' => 'required|string',
            'id_number' => 'required|string|max:100',
            'id_proof' => 'nullable|file|mimes:jpg,jpeg,png,pdf|max:2048',
            'selfie' => 'nullable|file|mimes:jpg,jpeg,png|max:2048'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation Error',
                'errors' => $validator->errors()
            ], 422);
        }

        $phone = $request->phone;
        $otp = $request->otp;

        // Verify OTP if phone is provided
        if ($phone) {
            $userCode = UserCode::where('phone', $phone)
                                ->where('purpose', 'login')
                                ->latest()
                                ->first();

            if (!$userCode) {
                return response()->json(['status' => false, 'message' => 'OTP not found'], 404);
            }

            if (now()->gt($userCode->expires_at)) {
                return response()->json(['status' => false, 'message' => 'OTP expired'], 400);
            }

            if ($userCode->attempts >= 5) {
                return response()->json(['status' => false, 'message' => 'Too many attempts'], 429);
            }

            if (!Hash::check($otp, $userCode->code_hash)) {
                $userCode->increment('attempts');
                return response()->json(['status' => false, 'message' => 'Invalid OTP'], 400);
            }

            // OTP is valid, delete code
            $userCode->delete();
        }

        DB::beginTransaction();

        try {
            // Create User
            $user = User::create([
                'name' => $request->name,
                'phone' => $request->phone ?? null,
                'email' => $request->email,
                'password' => Hash::make($request->password),
                'role' => $request->role,
                'is_active' => $request->is_active,
            ]);

            // Handle file uploads
            $idProofPath = null;
            $selfiePath = null;

            if ($request->hasFile('id_proof')) {
                $idProofFolder = 'employees/id_proofs';
                if (!Storage::exists($idProofFolder)) {
                    Storage::makeDirectory($idProofFolder);
                }
                $idProofPath = $request->file('id_proof')->store($idProofFolder);
            }

            if ($request->hasFile('selfie')) {
                $selfieFolder = 'employees/selfies';
                if (!Storage::exists($selfieFolder)) {
                    Storage::makeDirectory($selfieFolder);
                }
                $selfiePath = $request->file('selfie')->store($selfieFolder);
            }

            // Only create Employee if role is 'labor'
            $employee = null;
            if ($request->role === 'labor') {
                $employee = Employee::create([
                    'user_id' => $user->id,
                    'experience_years' => $request->experience_years,
                    'services' => $request->services,
                    'work_radius_km' => $request->work_radius_km ?? 5,
                    'hourly_rate' => $request->hourly_rate ?? 0,
                    'availability' => $request->availability ?? 'Full-Time',
                    'about' => $request->about,
                    'id_number' => $request->id_number,
                    'id_proof_path' => $idProofPath,
                    'selfie_path' => $selfiePath,
                    'phone_verified' => 1
                ]);
            }

            DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'User registered and verified successfully',
                'user' => $user,
                'employee' => $employee
            ], 201);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'status' => false,
                'message' => 'Registration failed: ' . $e->getMessage()
            ], 500);
        }
    }
    

    public function sendPhoneVerification(Request $request)
    {
        $request->validate([
            'phone' => 'required|string',
            'country_code' => 'required|string',
        ]);

        $code = rand(100000, 999999); // 6-digit code

        $userCode = UserCode::updateOrCreate(
            [
                'phone' => $request->phone,
                'purpose' => 'login'
            ],
            [
                'user_id' => auth()->id(), // optional if user logged in
                'country_code' => $request->country_code,
                'code_hash' => Hash::make($code),
                'expires_at' => Carbon::now()->addMinutes(10),
                'attempts' => 0
            ]
        );

        // Here you can send SMS with $code using your preferred SMS service

        return response()->json([
            'status' => true,
            'message' => 'Verification code sent successfully',
            'code' => $code // remove this in production!
        ]);
    }


    public function store(Request $request)
    {
        $request->validate([
            'user_id' => 'required|exists:users,id',
            'experience_years' => 'nullable|string|max:50',
            'services' => 'nullable|array',
            'work_radius_km' => 'nullable|integer',
            'hourly_rate' => 'nullable|numeric',
            'availability' => 'nullable|string|max:50',
            'about' => 'nullable|string',
            'id_number' => 'required|string|max:100',
            'id_proof' => 'nullable|file|mimes:jpg,jpeg,png,pdf',
            'selfie' => 'nullable|file|mimes:jpg,jpeg,png',
        ]);

        $data = $request->only([
            'user_id', 'experience_years', 'services', 'work_radius_km',
            'hourly_rate', 'availability', 'about', 'id_number'
        ]);

        // Handle file uploads
        if ($request->hasFile('id_proof')) {
            $data['id_proof_path'] = $request->file('id_proof')->store('id_proofs', 'public');
        }

        if ($request->hasFile('selfie')) {
            $data['selfie_path'] = $request->file('selfie')->store('selfies', 'public');
        }

        $employee = Employee::create($data);

        return response()->json([
            'status' => true,
            'message' => 'Employee data saved successfully',
            'employee' => $employee
        ]);
    }
}
