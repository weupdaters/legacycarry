<?php
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\AuthController;

Route::post('/login', [AuthController::class, 'login']);

Route::post('/users', [UserController::class, 'registerAndVerify']);
Route::post('/register-and-verify', [UserController::class, 'registerAndVerify']);
Route::post('/send-user-otp', [UserController::class, 'sendPhoneVerification']);

Route::middleware('auth:sanctum')->group(function () {
    Route::get('/profile', [AuthController::class, 'profile']);
    Route::post('/logout', [AuthController::class, 'logout']);
});

// Other API routes...
