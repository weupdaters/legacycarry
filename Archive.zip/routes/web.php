<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\UserController;

// Show login form
Route::get('/admin/login', function () {
    return view('auth.login');
})->name('admin.login');

// Handle login
Route::post('/admin/login', [AuthController::class, 'loginAdmin'])->name('admin.login.submit');

// Dashboard (only for super_admin)
Route::prefix('admin')->middleware(['isSuperAdmin'])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('admin.dashboard');

    // User management routes
    Route::get('/users', [UserController::class, 'index'])->name('users.index');
    Route::get('/users/create', [UserController::class, 'create'])->name('users.create');
    Route::post('/users', [UserController::class, 'store'])->name('users.store');
    Route::get('/users/{user}/edit', [UserController::class, 'edit'])->name('users.edit');
    Route::put('/users/{user}', [UserController::class, 'update'])->name('users.update');
});

// Logout route
Route::get('/logout', function () {
    Auth::logout();     
    return redirect()->route('admin.login');
})->name('logout');
