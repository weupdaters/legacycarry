<!-- Topbar Start -->
<div class="topbar-custom">
    <div class="container-fluid">
        <div class="d-flex justify-content-between">

            <!-- Left side -->
            <ul class="list-unstyled topnav-menu mb-0 d-flex align-items-center">
                <li>
                    <button class="button-toggle-menu nav-link">
                        <i data-feather="menu" class="noti-icon"></i>
                    </button>
                </li>
                <li class="d-none d-lg-block">
                    <?php
                        $hour = now()->format('H'); // 24-hour format
                        if($hour < 12){
                            $greeting = 'Good Morning';
                        } elseif($hour < 18){
                            $greeting = 'Good Afternoon';
                        } else {
                            $greeting = 'Good Evening';
                        }
                    ?>

                    <h5 class="mb-0"><?php echo e($greeting); ?>, <?php echo e(Auth::user()->name); ?></h5>
                </li>
            </ul>

            <!-- Right side -->
            <ul class="list-unstyled topnav-menu mb-0 d-flex align-items-center">

                <!-- Search -->
                

                <!-- Fullscreen Button -->
                <li class="d-none d-sm-flex">
                    <button type="button" class="btn nav-link" data-toggle="fullscreen">
                        <i data-feather="maximize" class="align-middle fullscreen noti-icon"></i>
                    </button>
                </li>

                <!-- Light/Dark Mode -->
                <li class="d-none d-sm-flex">
                    <button type="button" class="btn nav-link" id="light-dark-mode">
                        <i data-feather="moon" class="align-middle dark-mode"></i>
                        <i data-feather="sun" class="align-middle light-mode"></i>
                    </button>
                </li>

                <!-- Notifications -->
                

                <!-- User Dropdown -->
                <li class="dropdown notification-list topbar-dropdown">
                    <a class="nav-link dropdown-toggle nav-user me-0" data-bs-toggle="dropdown" href="#" role="button"
                        aria-haspopup="false" aria-expanded="false">
                        <img src="<?php echo e(asset('assets/images/users/user-13.jpg')); ?>" alt="user-image" class="rounded-circle" />
                        <span class="pro-user-name ms-1"><?php echo e(Auth::user()->name); ?> <i class="mdi mdi-chevron-down"></i></span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end profile-dropdown">
                        <div class="dropdown-header noti-title">
                            <h6 class="text-overflow m-0">Welcome !</h6>
                        </div>

                        <a href="<?php echo e(url('pages-profile')); ?>" class="dropdown-item notify-item">
                            <i class="mdi mdi-account-circle-outline fs-16 align-middle"></i>
                            <span>My Account</span>
                        </a>

                        <a href="<?php echo e(url('auth-lock-screen')); ?>" class="dropdown-item notify-item">
                            <i class="mdi mdi-lock-outline fs-16 align-middle"></i>
                            <span>Lock Screen</span>
                        </a>

                        <div class="dropdown-divider"></div>

                        <a href="<?php echo e(route('logout')); ?>" class="dropdown-item notify-item">
                            <i class="mdi mdi-location-exit fs-16 align-middle"></i>
                            <span>Logout</span>
                        </a>
                    </div>
                </li>

            </ul>
        </div>
    </div>
</div>
<!-- end Topbar -->

<!-- Left Sidebar Start -->
<div class="app-sidebar-menu">
    <div class="h-100" data-simplebar>

        <div id="sidebar-menu">

            <!-- Logo -->
            <div class="logo-box">
                <a href="<?php echo e(url('index')); ?>" class="logo logo-light">
                    <span class="logo-sm">
                        <img src="<?php echo e(asset('assets/images/logo-sm.png')); ?>" alt="" height="22">
                    </span>
                    <span class="logo-lg">
                        <img src="<?php echo e(asset('assets/images/logo-light.png')); ?>" alt="" height="24">
                    </span>
                </a>
                <a href="<?php echo e(url('index')); ?>" class="logo logo-dark">
                    <span class="logo-sm">
                        <img src="<?php echo e(asset('assets/images/logo-sm.png')); ?>" alt="" height="22">
                    </span>
                    <span class="logo-lg">
                        <img src="<?php echo e(asset('assets/images/logo-dark.png')); ?>" alt="" height="24">
                    </span>
                </a>
            </div>

            <ul id="side-menu">
                <li class="menu-title">Menu</li>

                <li>
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="tp-link">
                        <i data-feather="home"></i>
                        <span> Dashboard </span>
                    </a>
                </li>
                

                <!-- Authentication -->
                <li class="menu-title">Authentication</li>
                <li>
                    <a href="<?php echo e(route('users.index')); ?>" class="tp-link">
                        <i data-feather="users"></i>
                        <span> Users </span>
                    </a>
                </li>
                <!-- Add other menus here, same pattern, using `url()` for links -->

            </ul>

        </div>
        <!-- End Sidebar -->

        <div class="clearfix"></div>
    </div>
</div>
<!-- Left Sidebar End -->
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/legacy_carry/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>