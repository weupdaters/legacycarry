<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" data-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="apple-mobile-web-app-capable" content="yes">

    <title><?php echo e(config('app.name', 'Laravel')); ?> | <?php echo $__env->yieldContent('title', 'Dashboard'); ?></title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>">

    <link href="<?php echo e(asset('assets/libs/simple-datatables/style.css')); ?>" rel="stylesheet" type="text/css" />

    <!-- App CSS -->
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="app-style" />
    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />

    <!-- Page-specific CSS -->
    <?php echo $__env->yieldPushContent('styles'); ?>

    <!-- Head JS -->
    <script src="<?php echo e(asset('assets/js/head.js')); ?>"></script>
</head>
<body data-menu-color="light" data-sidebar="default">

    <!-- Loader Start -->
    <div id="loading">
        <div id="loading-center"></div>
    </div>
    <!-- Loader End -->

    <!-- Begin page -->
    <div id="app-layout">
        <!-- Sidebar -->
        <?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

       

        <!-- Modals -->
        <?php echo $__env->make('layouts.model', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- Page Content -->
        <div class="content-page">
            <div class="content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>

            <!-- Footer Start -->
            <footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col fs-13 text-muted text-center">
                            &copy; <script>document.write(new Date().getFullYear())</script> - Made with 
                            <span class="mdi mdi-heart text-danger"></span> by 
                            <a href="#!" class="text-reset fw-semibold">weupdaters</a>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- Footer End -->

        </div>
        <!-- End Page Content -->

    </div>
    <!-- END Wrapper -->

     <!-- Notifications -->
     <?php echo $__env->make('layouts.notification', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Vendor JS -->
    <script src="<?php echo e(asset('assets/libs/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/simplebar/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/node-waves/waves.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/waypoints/lib/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/jquery.counterup/jquery.counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/feather-icons/feather.min.js')); ?>"></script>

    <!-- ApexCharts -->
    <script src="<?php echo e(asset('assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>
    <script src="https://apexcharts.com/samples/assets/stock-prices.js"></script>

    <!-- Page/Widgets JS -->
    <script src="<?php echo e(asset('assets/js/pages/hrm-dashboard.init.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>

    <!-- Simple Datatables JS -->
    <script src="<?php echo e(asset('assets/libs/simple-datatables/umd/simple-datatables.js')); ?>"></script>

    <!-- Simple Datatables Init JS -->
    <script src="<?php echo e(asset('assets/js/pages/simple-datatables.init.js')); ?>"></script>

    <!-- Page-specific JS -->
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/legacy_carry/resources/views/layouts/app.blade.php ENDPATH**/ ?>